from __future__ import annotations
import os, json, ssl
from datetime import datetime

NFL_SPORT_KEY="americanfootball_nfl"

def _require_pregame(snapshot_time, kickoff_time):
    s=datetime.fromisoformat(str(snapshot_time).replace("Z","+00:00"))
    k=datetime.fromisoformat(str(kickoff_time).replace("Z","+00:00"))
    if s >= k:
        raise ValueError("Pregame guard failed: snapshot_time must be before kickoff_time")

class NFLverseProvider:
    def load(self, seasons):
        try:
            import nflreadpy as nfl
        except ImportError as e:
            raise RuntimeError("Install nflreadpy first: python3 -m pip install nflreadpy") from e
        seasons=list(map(int,seasons))
        return {"pbp": nfl.load_pbp(seasons), "schedules": nfl.load_schedules(seasons), "team_stats": nfl.load_team_stats(seasons)}

class OddsAPIProvider:
    def __init__(self, api_key=None):
        self.api_key=api_key or os.getenv("ODDS_API_KEY") or os.getenv("THE_ODDS_API_KEY")
        if not self.api_key:
            raise RuntimeError("ODDS_API_KEY is not set")

    def fetch_nfl(self, bookmaker=None):
        import urllib.parse, urllib.request
        q={"apiKey":self.api_key,"regions":"us","markets":"h2h,spreads","oddsFormat":"american","dateFormat":"iso"}
        if bookmaker: q["bookmakers"]=bookmaker
        url="https://api.the-odds-api.com/v4/sports/"+NFL_SPORT_KEY+"/odds?"+urllib.parse.urlencode(q)
        try:
            import certifi
            ctx=ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            ctx=ssl.create_default_context()
        with urllib.request.urlopen(url,timeout=30,context=ctx) as r:
            return json.loads(r.read().decode("utf-8"))

    @staticmethod
    def normalize_event(event, bookmaker_key):
        books={b["key"]:b for b in event.get("bookmakers",[])}
        if bookmaker_key not in books: raise KeyError(f"{bookmaker_key} not available for event")
        b=books[bookmaker_key]; markets={m["key"]:m for m in b.get("markets",[])}
        if "h2h" not in markets or "spreads" not in markets: raise ValueError("Required h2h/spreads markets unavailable")
        h={x["name"]:x for x in markets["h2h"]["outcomes"]}; s={x["name"]:x for x in markets["spreads"]["outcomes"]}
        home=event["home_team"]; away=event["away_team"]
        snapshot=b.get("last_update") or markets["h2h"].get("last_update"); kickoff=event["commence_time"]
        _require_pregame(snapshot,kickoff)
        return {"event_id":event["id"],"snapshot_time":snapshot,"kickoff_time":kickoff,"home_team":home,"away_team":away,"bookmaker":bookmaker_key,
                "home_moneyline":float(h[home]["price"]),"away_moneyline":float(h[away]["price"]),"market_home_margin":float(s[home]["point"]),
                "home_spread_odds":float(s[home]["price"]),"away_spread_odds":float(s[away]["price"])}
