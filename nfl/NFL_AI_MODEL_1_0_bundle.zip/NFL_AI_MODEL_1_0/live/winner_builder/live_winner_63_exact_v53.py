import pandas as pd
import numpy as np

def pdx(x): return x.to_pandas() if hasattr(x,"to_pandas") else pd.DataFrame(x)

def col(d,n,default=np.nan): return d[n] if n in d.columns else pd.Series(default,index=d.index)

def num(d,n,default=np.nan): return pd.to_numeric(col(d,n,default),errors="coerce")

def build_exact_v53(hist_s,hist_pb,s26,pb26,F):
    s=pd.concat([hist_s,s26],ignore_index=True)
    pb=pd.concat([hist_pb,pb26],ignore_index=True)
    s["gameday"]=pd.to_datetime(col(s,"gameday"),errors="coerce")
    for c in ["season","week","home_score","away_score"]: s[c]=num(s,c)
    s["home_team"]=col(s,"home_team").astype(str)
    s["away_team"]=col(s,"away_team").astype(str)
    done=s.dropna(subset=["gameday","home_score","away_score"]).copy().sort_values("gameday")
    done["home_win"]=(done.home_score>done.away_score).astype(int)
    for c in ["season","week"]: pb[c]=num(pb,c)
    pb["posteam"]=col(pb,"posteam").astype(str)
    pb["defteam"]=col(pb,"defteam").astype(str)
    pb["epa"]=num(pb,"epa")
    pb["success"]=num(pb,"success")
    for c in ["pass_attempt","rush_attempt","sack","interception","fumble_lost","complete_pass","qb_hit"]:
        pb[c]=num(pb,c,0).fillna(0)
    pb["yardline_100"]=num(pb,"yardline_100")
    pb["yards_gained"]=num(pb,"yards_gained")
    pb["passer_player_id"]=col(pb,"passer_player_id").astype(str)
    pb["air_yards"]=num(pb,"air_yards")
    pb["play_ok"]=pb.posteam.ne("nan") & pb.defteam.ne("nan") & pb.epa.notna() & ((pb.pass_attempt==1)|(pb.rush_attempt==1)|(pb.sack==1))
    pb["succx"]=pb["success"].where(pb["success"].notna(),(pb["epa"]>0).astype(float))
    pb["explosive"]=(((pb.pass_attempt==1)&(pb.yards_gained>=20))|((pb.rush_attempt==1)&(pb.yards_gained>=10))).astype(float)
    pb["rz"]=((pb.yardline_100<=20)&pb.yardline_100.notna()).astype(float)
    pb["turnover"]=(pb.interception+pb.fumble_lost).clip(0,1)
    pb=pb[pb.play_ok].copy()
    off=pb.groupby(["season","week","posteam"]).agg(off_epa=("epa","mean"),off_success=("succx","mean"),
     off_explosive=("explosive","mean"),off_turnover=("turnover","mean"),off_sack=("sack","mean"),
     off_rz_rate=("rz","mean"),qb_hit_rate=("qb_hit","mean"),plays=("epa","size")).reset_index().rename(columns={"posteam":"team"})
    qbplays=pb[(pb.pass_attempt==1)|(pb.sack==1)].copy()
    qbg=qbplays.groupby(["season","week","posteam","passer_player_id"]).agg(qb_epa=("epa","mean"),qb_success=("succx","mean"),
     qb_int_rate=("interception","mean"),qb_sack_rate=("sack","mean"),qb_air_yards=("air_yards","mean"),
     qb_dropbacks=("epa","size")).reset_index().sort_values(["season","week","posteam","qb_dropbacks"],ascending=[1,1,1,0])
    qbg=qbg.drop_duplicates(["season","week","posteam"]).rename(columns={"posteam":"team","passer_player_id":"primary_qb"})
    de=pb.groupby(["season","week","defteam"]).agg(def_epa_allowed=("epa","mean"),def_success_allowed=("succx","mean"),
     def_explosive_allowed=("explosive","mean"),def_takeaway=("turnover","mean"),
     def_sack_created=("sack","mean")).reset_index().rename(columns={"defteam":"team"})
    eff=off.merge(de,on=["season","week","team"],how="outer").merge(qbg,on=["season","week","team"],how="left")
    h=done[["gameday","season","week","home_team","away_team","home_score","away_score"]].copy()
    h.columns=["gameday","season","week","team","opp","pf","pa"]
    h["home"]=1
    a=done[["gameday","season","week","away_team","home_team","away_score","home_score"]].copy()
    a.columns=["gameday","season","week","team","opp","pf","pa"]
    a["home"]=0
    tg=pd.concat([h,a],ignore_index=True).merge(eff,on=["season","week","team"],how="left").sort_values(["team","gameday"])
    tg["margin"]=tg.pf-tg.pa
    tg["win"]=(tg.margin>0).astype(float)
    tg["prev"]=tg.groupby("team").gameday.shift()
    tg["rest"]=(tg.gameday-tg.prev).dt.days.clip(3,14)
    base=["pf","pa","margin","win"]
    advanced=["off_epa","off_success","off_explosive","off_turnover","off_sack","off_rz_rate","def_epa_allowed",
    "def_success_allowed","def_explosive_allowed","def_takeaway","def_sack_created","qb_hit_rate","qb_epa","qb_success",
    "qb_int_rate","qb_sack_rate","qb_air_yards"]
    tg["prev_primary_qb"]=tg.groupby("team")["primary_qb"].shift(1)
    tg["qb_change"]=((tg.primary_qb.notna())&(tg.prev_primary_qb.notna())&(tg.primary_qb!=tg.prev_primary_qb)).astype(float)
    advanced+=["qb_change"]
    for sp in [6,12]:
        for c in base+advanced:
            tg[f"s{sp}_{c}"]=tg.groupby("team")[c].transform(lambda z:z.shift(1).ewm(span=sp,min_periods=3,adjust=False).mean())
    for sp in [6,12]:
        tg[f"s{sp}_net_epa"]=tg[f"s{sp}_off_epa"]-tg[f"s{sp}_def_epa_allowed"]
        tg[f"s{sp}_net_success"]=tg[f"s{sp}_off_success"]-tg[f"s{sp}_def_success_allowed"]
    cols=[f"s{x}_{c}" for x in [6,12] for c in base+["off_epa","off_success","def_epa_allowed","def_success_allowed"]]+[f"s{x}_net_epa" for x in [6,12]]+[f"s{x}_net_success" for x in [6,12]]+["rest"]
    H=tg[tg.home.eq(1)][["gameday","season","week","team"]+cols].rename(columns={"team":"home_team",**{c:"H_"+c for c in cols}})
    A=tg[tg.home.eq(0)][["gameday","season","week","team"]+cols].rename(columns={"team":"away_team",**{c:"A_"+c for c in cols}})
    d=done.merge(H,on=["gameday","season","week","home_team"],how="left").merge(A,on=["gameday","season","week","away_team"],how="left")
    for c in cols: d["D_"+c]=d["H_"+c]-d["A_"+c]
    missing=[x for x in F if x not in d]
    if missing: raise RuntimeError("Feature contract mismatch "+repr(missing))
    o=d[pd.to_numeric(d.season,errors="coerce").eq(2026)].copy()
    ids=[c for c in ["game_id","season","week","gameday","home_team","away_team","home_score","away_score","home_win"] if c in o]
    o=o[ids+F]
    arr=o[F].apply(pd.to_numeric,errors="coerce").to_numpy(float)
    finite=np.isfinite(arr).all(axis=1)
    return o
