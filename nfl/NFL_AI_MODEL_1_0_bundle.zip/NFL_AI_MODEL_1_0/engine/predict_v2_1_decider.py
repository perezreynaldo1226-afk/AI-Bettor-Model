"""
DECISION_V2_1_CORRECTED_THRESHOLDS -- same design as predict_v2_decider.py
(walk-forward EV/edge threshold gate on top of the SAME frozen WINNER and
SPREAD models, unmodified), with tau_ml/tau_spread recalibrated after fixing
a real bug: every earlier backtest that pulled historical odds from
nflverse's public games.csv computed market_home_margin as `-spread_line`.
That transform was correct for this project's own original odds source, but
nflverse's games.csv uses the opposite sign convention for spread_line
(positive = home favored). Verified via corr(spread_line, moneyline-implied
home win probability) = 0.99, and via a naive "always bet home" baseline
covering 49.2% of the time under the corrected sign vs an implausible 57.0%
under the old, buggy one.

Recalibration result (single frozen threshold, chosen using ONLY 2018-2021
data, corrected sign, never re-touched with 2022-2025 or 2026 data):
  tau_ml:     0.19  (UNCHANGED from V2 -- ML EV never depended on
              market_home_margin's sign, so this number was never affected
              by the bug in the first place)
  tau_spread: 2.00  (CHANGED from V2's 4.0 -- that 4.0 was an artifact of
              the sign bug: it was the frozen Spread model's coarse output
              hitting a tiny, lucky-looking bucket of mislabeled games.
              2.0 is calibrated on far more trades -- 232 vs the old 37 --
              and is the honestly-best-supported number available for
              this specific frozen model.)

IMPORTANT CAVEAT, carried over honestly rather than hidden: fixing the sign
bug does NOT make this a clean out-of-sample test. The frozen Spread model
(SPREAD_MKT_EPA_HGB_DEPLOYMENT_REFIT_PRE2026) was itself trained on
2022-2025 -- the same seasons used to pick tau_spread here. A fully clean
test (new models trained ONLY on 2018-2021, evaluated on 2022-2025 they
never saw) found NO real signal in the spread side at all (correlation
~0.03, indistinguishable from noise) and NO statistically significant edge
in the combined gated decider (ROI 95% CI [-8.4%, +7.5%], straddling zero).
So: these are the best-supported thresholds for the decider that is
actually live (frozen models + threshold gate), now that the data feeding
the threshold search is correct -- but "best-supported" here still falls
short of "proven." The live PROSPECTIVE_TRACKER is the only way to actually
resolve that, which is exactly what it is for.

Reuses the exact same frozen WINNER_EPA_CORE_LR_PRE2026 and
SPREAD_MKT_EPA_HGB_DEPLOYMENT_REFIT_PRE2026 joblib artifacts as
predict_v2_decider.py and the live app, unmodified. Does not modify
engine/predict.py, app/prediction_service.py, or predict_v2_decider.py
(kept as-is for the record). Not yet wired into the live app. Not
authorized for real stakes.
"""
from pathlib import Path
import joblib
import pandas as pd

TAU_ML = 0.19
TAU_SPREAD = 2.0

BASE = Path(__file__).resolve().parent.parent  # expected to sit alongside engine/ when installed there
_ART_CANDIDATES = [
    BASE / "artifacts",
    Path("/Users/rey/Desktop/Sport Bet/NFL_AI_MODEL_1_0/artifacts"),
]


def _load_artifacts():
    for art in _ART_CANDIDATES:
        w = art / "WINNER_EPA_CORE_LR_PRE2026.joblib"
        s = art / "SPREAD_MKT_EPA_HGB_DEPLOYMENT_REFIT_PRE2026.joblib"
        if w.exists() and s.exists():
            return joblib.load(w), joblib.load(s)
    raise FileNotFoundError("Could not locate frozen WINNER/SPREAD artifacts in any candidate path.")


WINNER, SPREAD = _load_artifacts()


def american_profit(o):
    o = float(o)
    if o == 0:
        raise ValueError("American odds cannot be zero")
    return o / 100 if o > 0 else 100 / abs(o)


def winner_predict(row):
    f = WINNER["features"]
    X = pd.DataFrame([{c: row.get(c) for c in f}], columns=f)
    p = float(WINNER["model"].predict_proba(X)[0, 1])
    return {"p_home_win": p, "p_away_win": 1 - p, "winner_side": "HOME" if p >= .5 else "AWAY",
            "winner_confidence": max(p, 1 - p), "ml_pick_home": int(p >= .5)}


def spread_predict(market_home_margin, home_moneyline, away_moneyline):
    f = SPREAD["features"]
    r = {"market_home_margin": float(market_home_margin), "home_moneyline": float(home_moneyline),
         "away_moneyline": float(away_moneyline)}
    X = pd.DataFrame([[r[c] for c in f]], columns=f)
    resid = float(SPREAD["model"].predict(X)[0])
    pred = float(market_home_margin) + resid
    edge = pred - float(market_home_margin)  # == resid, kept explicit for auditability
    return {"pred_home_margin": pred, "model_edge": edge, "spread_edge": edge, "spread_pick_home": int(edge > 0)}


def decide_v2_1(w, s, home_moneyline, away_moneyline, home_spread_odds, away_spread_odds,
                 tau_ml=TAU_ML, tau_spread=TAU_SPREAD):
    """Walk-forward-gated action selection, corrected-sign-calibrated thresholds. Returns dict with action/side/odds, or PASS."""
    p = w["p_home_win"]
    ml_side = "HOME" if p >= 0.5 else "AWAY"
    ml_odds = float(home_moneyline if ml_side == "HOME" else away_moneyline)
    p_side = p if ml_side == "HOME" else 1 - p
    ml_ev = p_side * american_profit(ml_odds) - (1 - p_side)

    edge = s["spread_edge"]
    sp_side = "HOME" if edge > 0 else "AWAY"
    sp_odds = float(home_spread_odds if sp_side == "HOME" else away_spread_odds)
    sp_edge_abs = abs(edge)

    ml_ok = ml_ev >= tau_ml
    sp_ok = sp_edge_abs >= tau_spread

    if ml_ok and sp_ok:
        ml_margin = ml_ev - tau_ml
        sp_margin = (sp_edge_abs - tau_spread) / 6.0
        action = "ML" if ml_margin >= sp_margin else "SPREAD"
    elif ml_ok:
        action = "ML"
    elif sp_ok:
        action = "SPREAD"
    else:
        action = "PASS"

    if action == "ML":
        side, odds = ml_side, ml_odds
    elif action == "SPREAD":
        side, odds = sp_side, sp_odds
    else:
        side, odds = None, None

    return {"action": action, "side": side, "selected_odds": odds,
            "ml_ev": ml_ev, "spread_edge_abs": sp_edge_abs,
            "tau_ml": tau_ml, "tau_spread": tau_spread, "decider_version": "V2_1_CORRECTED_THRESHOLDS"}


def predict_game_v2_1(*, winner_features, home_moneyline, away_moneyline, market_home_margin,
                       home_spread_odds, away_spread_odds, stake=50.0):
    """Same call signature/shape as engine/predict.py::predict_game, using the recalibrated decider."""
    w = winner_predict(winner_features)
    s = spread_predict(market_home_margin, home_moneyline, away_moneyline)
    d = decide_v2_1(w, s, home_moneyline, away_moneyline, home_spread_odds, away_spread_odds)
    stake = float(stake)
    profit = 0.0 if d["action"] == "PASS" else stake * american_profit(d["selected_odds"])
    return {"model_version": "NFL_AI_MODEL_1.0+DECISION_V2_1_CORRECTED_THRESHOLDS", "winner": w, "spread": s,
            "decision": d, "stake": stake, "profit_if_wins": profit,
            "total_return_if_wins": stake + profit if d["action"] != "PASS" else 0.0}
