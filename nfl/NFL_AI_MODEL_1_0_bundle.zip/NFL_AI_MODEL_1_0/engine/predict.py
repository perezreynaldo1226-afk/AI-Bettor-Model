from pathlib import Path
import joblib,numpy as np,pandas as pd
BASE=Path(__file__).resolve().parent.parent; A=BASE/"artifacts"
WINNER=joblib.load(A/"WINNER_EPA_CORE_LR_PRE2026.joblib")
SPREAD=joblib.load(A/"SPREAD_MKT_EPA_HGB_DEPLOYMENT_REFIT_PRE2026.joblib")
DECISION=joblib.load(A/"DECISION_AI_LIVE_STATE_PRE2026.joblib")
def american_profit(o):
    o=float(o)
    if o==0: raise ValueError("American odds cannot be zero")
    return o/100 if o>0 else 100/abs(o)
def winner_predict(row):
    f=WINNER["features"]; X=pd.DataFrame([{c:row.get(c) for c in f}],columns=f)
    p=float(WINNER["model"].predict_proba(X)[0,1])
    return {"p_home_win":p,"p_away_win":1-p,"winner_side":"HOME" if p>=.5 else "AWAY","winner_confidence":max(p,1-p),"ml_pick_home":int(p>=.5)}
def spread_predict(market_home_margin,home_moneyline,away_moneyline):
    f=SPREAD["features"]; r={"market_home_margin":float(market_home_margin),"home_moneyline":float(home_moneyline),"away_moneyline":float(away_moneyline)}
    X=pd.DataFrame([[r[c] for c in f]],columns=f); resid=float(SPREAD["model"].predict(X)[0])
    pred=float(market_home_margin)+resid; edge=pred-float(market_home_margin)
    return {"pred_home_margin":pred,"model_edge":edge,"spread_edge":edge,"spread_pick_home":int(edge>0)}
def decision_predict(w,s,home_moneyline,away_moneyline,market_home_margin,home_spread_odds,away_spread_odds):
    mh=int(float(home_moneyline)<float(away_moneyline)); mlh=w["ml_pick_home"]; sph=s["spread_pick_home"]
    v={"ml_confidence_unified":w["winner_confidence"],"winner_uncertainty":1-w["winner_confidence"],
       "abs_market_spread":abs(float(market_home_margin)),"spread_edge":s["spread_edge"],"abs_spread_edge":abs(s["spread_edge"]),
       "ml_pick_home":mlh,"spread_pick_home":sph,"ml_market_same_side":int(mlh==mh)}
    f=DECISION["features"]; X=pd.DataFrame([[v[c] for c in f]],columns=f)
    raw=float(DECISION["ml_correctness_model"].predict_proba(X)[0,1]); ps=float(DECISION["spread_correctness_model"].predict_proba(X)[0,1])
    q=np.clip(raw,1e-6,1-1e-6); z=np.array([[np.log(q/(1-q))]])
    pm=float(DECISION["ml_platt"].predict_proba(z)[0,1])
    mo=float(home_moneyline if mlh else away_moneyline); so=float(home_spread_odds if sph else away_spread_odds)
    mev=pm*american_profit(mo)-(1-pm); sev=ps*american_profit(so)-(1-ps)
    recal=max({"ML":mev,"SPREAD":sev,"PASS":0.0},key={"ML":mev,"SPREAD":sev,"PASS":0.0}.get)
    bp=float(DECISION["spread_beta"]["p"]); bsev=bp*american_profit(so)-(1-bp)
    base=max({"ML":mev,"SPREAD":bsev,"PASS":0.0},key={"ML":mev,"SPREAD":bsev,"PASS":0.0}.get)
    action=base if recal=="PASS" else recal
    side=("HOME" if mlh else "AWAY") if action=="ML" else (("HOME" if sph else "AWAY") if action=="SPREAD" else None)
    odds=mo if action=="ML" else (so if action=="SPREAD" else None)
    return {"action":action,"side":side,"p_ml_correct":pm,"p_spread_correct":ps,"ml_ev":mev,"spread_ev":sev,"base_spread_ev":bsev,"recal_action":recal,"fallback_action":base,"selected_odds":odds}
def predict_game(*,winner_features,home_moneyline,away_moneyline,market_home_margin,home_spread_odds,away_spread_odds,stake=50.0):
    w=winner_predict(winner_features); s=spread_predict(market_home_margin,home_moneyline,away_moneyline)
    d=decision_predict(w,s,home_moneyline,away_moneyline,market_home_margin,home_spread_odds,away_spread_odds); stake=float(stake)
    profit=0.0 if d["action"]=="PASS" else stake*american_profit(d["selected_odds"])
    return {"model_version":"NFL_AI_MODEL_1.0","winner":w,"spread":s,"decision":d,"stake":stake,"profit_if_wins":profit,"total_return_if_wins":stake+profit if d["action"]!="PASS" else 0.0}
