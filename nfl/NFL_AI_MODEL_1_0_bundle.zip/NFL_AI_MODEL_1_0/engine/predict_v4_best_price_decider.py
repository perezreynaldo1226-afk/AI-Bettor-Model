"""
DECISION_V4_BEST_PRICE_ML_ONLY -- same frozen WINNER model, same
walk-forward-validated tau_ml=0.19 threshold and same ML-only side
selection as V3 (predict_v3_ml_only_decider.py, unmodified, imported not
reimplemented), but instead of taking a single scalar home_moneyline/
away_moneyline, takes the FULL set of per-bookmaker odds rows for a game
(the exact schema SUPPORT/fetch_week_odds.py already produces -- one row
per (game_id, bookmaker)) and always evaluates EV, and places the pick,
at the single best price available across every book quoting that game.

WHY THIS EXISTS
----------------
Every decider through V3 took one already-chosen scalar price per side.
But SUPPORT/fetch_week_odds.py has been pulling EVERY bookmaker The Odds
API returns for each game all along (one row per game_id+bookmaker), and
SUPPORT/MODEL_1_1_PROSPECTIVE_GUARDED.py --lock already loops over every
one of those book-rows independently -- the multi-book data was already
being collected and priced per-book, but nothing compared across books
for the SAME selected side and took the best number before logging or
acting. That's a real, well-established source of value that doesn't
require the model's probabilities to beat the market at all: it only
requires that different books don't move in perfect lockstep, which they
don't. This captures it.

This does NOT change the model, the side-selection logic, or tau_ml.
decide_v3_ml_only is imported and called unmodified -- this file only
changes what odds are handed to it, and records which book supplied the
winning price for full auditability.

For American odds, "best for the bettor" is always the numerically
LARGEST value, whether positive or negative: +160 beats +150 (bigger
payout on the same win), and -105 beats -110 (less risked for the same
$100 return). So a single max() over available quotes for each side is
correct without special-casing signs -- verified by the self-test below.

Does not modify predict_v3_ml_only_decider.py, predict_v2_1_decider.py,
engine/predict.py, or any frozen artifact. Not yet wired into the live
app. Not authorized for real stakes. Not a claim of new predictive edge
-- the WINNER model and tau_ml are identical to V3. This is purely a
bet-EXECUTION improvement (best price), tracked prospectively alongside
OLD/V2.1/V3, never touching 2026 outcomes to pick or adjust anything.
"""
import math
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from predict_v3_ml_only_decider import (  # noqa: E402  (reuse, do not reimplement)
    WINNER, american_profit, decide_v3_ml_only, winner_predict,
)

TAU_ML = 0.19  # identical to V3 -- not re-tuned here


def _is_valid_price(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return False
    return not math.isnan(v) and v != 0


def select_best_price(book_rows):
    """book_rows: list of dicts (or DataFrame records), each with at least
    'bookmaker', 'home_moneyline', 'away_moneyline'. Returns the best
    (numerically largest, i.e. most favorable to the bettor) price for
    each side across all books that quoted a valid price for it, plus
    which book supplied it. Raises if no book offers a valid price for a
    given side at all -- never silently substitutes or fabricates a
    number.
    """
    if hasattr(book_rows, "to_dict"):
        book_rows = book_rows.to_dict("records")
    book_rows = list(book_rows)
    if not book_rows:
        raise ValueError("select_best_price: no book rows supplied for this game")

    best = {}
    for side, col in (("HOME", "home_moneyline"), ("AWAY", "away_moneyline")):
        candidates = [(r["bookmaker"], float(r[col])) for r in book_rows
                      if col in r and _is_valid_price(r[col])]
        if not candidates:
            raise ValueError(f"select_best_price: no valid {col} quoted by any book for this game")
        book, price = max(candidates, key=lambda bp: bp[1])
        best[side] = {"price": price, "book": book, "n_books_quoting": len(candidates)}
    return best


def decide_v4_best_price(w, book_rows, tau_ml=TAU_ML):
    """Best-of-book moneyline-only action selection. Finds the single best
    available price for each side across all quoting books, then defers
    entirely to the unmodified V3 decide_v3_ml_only for side selection and
    the EV-vs-tau decision, using those best prices. Never selects SPREAD
    (same restriction as V3 -- this decider does not load or use the
    Spread model at all).
    """
    best = select_best_price(book_rows)
    d = decide_v3_ml_only(w, best["HOME"]["price"], best["AWAY"]["price"], tau_ml=tau_ml)
    used_side = d["side"]
    d["decider_version"] = "V4_BEST_PRICE_ML_ONLY_TAU019"
    d["priced_book"] = best[used_side]["book"] if used_side else None
    d["n_books_quoting_home"] = best["HOME"]["n_books_quoting"]
    d["n_books_quoting_away"] = best["AWAY"]["n_books_quoting"]
    d["best_home_moneyline"] = best["HOME"]["price"]
    d["best_home_book"] = best["HOME"]["book"]
    d["best_away_moneyline"] = best["AWAY"]["price"]
    d["best_away_book"] = best["AWAY"]["book"]
    return d


def predict_game_v4(*, winner_features, book_rows, stake=50.0):
    """Same call-signature spirit as engine/predict.py::predict_game and
    predict_v3_ml_only_decider.py::predict_game_v3, using the best-of-book
    moneyline-only decider."""
    w = winner_predict(winner_features)
    d = decide_v4_best_price(w, book_rows)
    stake = float(stake)
    profit = 0.0 if d["action"] == "PASS" else stake * american_profit(d["selected_odds"])
    return {"model_version": "NFL_AI_MODEL_1.0+DECISION_V4_BEST_PRICE_ML_ONLY", "winner": w,
            "decision": d, "stake": stake, "profit_if_wins": profit,
            "total_return_if_wins": stake + profit if d["action"] != "PASS" else 0.0}


if __name__ == "__main__":
    # ---- self-test / smoke test, run before delivering ----
    books_case1 = [
        {"bookmaker": "bookA", "home_moneyline": -120, "away_moneyline": 105},
        {"bookmaker": "bookB", "home_moneyline": -105, "away_moneyline": 100},
        {"bookmaker": "bookC", "home_moneyline": -130, "away_moneyline": 115},
    ]
    best1 = select_best_price(books_case1)
    assert best1["HOME"]["price"] == -105 and best1["HOME"]["book"] == "bookB", best1
    assert best1["AWAY"]["price"] == 115 and best1["AWAY"]["book"] == "bookC", best1
    print("Case 1 (best-price selection, mixed signs) PASS:", best1)

    w_home_favored = {"p_home_win": 0.62, "p_away_win": 0.38,
                       "winner_side": "HOME", "winner_confidence": 0.62, "ml_pick_home": 1}
    d_v3_manual = decide_v3_ml_only(w_home_favored, best1["HOME"]["price"], best1["AWAY"]["price"])
    d_v4 = decide_v4_best_price(w_home_favored, books_case1)
    assert d_v4["action"] == d_v3_manual["action"]
    assert d_v4["side"] == d_v3_manual["side"]
    assert d_v4["selected_odds"] == d_v3_manual["selected_odds"]
    assert abs(d_v4["ml_ev"] - d_v3_manual["ml_ev"]) < 1e-12
    assert d_v4["priced_book"] == "bookB"
    print("Case 2 (V4 matches V3 exactly given best-of-book prices) PASS:", d_v4)

    w_away_favored = {"p_home_win": 0.35, "p_away_win": 0.65,
                       "winner_side": "AWAY", "winner_confidence": 0.65, "ml_pick_home": 0}
    d_v4_away = decide_v4_best_price(w_away_favored, books_case1)
    if d_v4_away["action"] != "PASS":
        assert d_v4_away["side"] == "AWAY"
        assert d_v4_away["priced_book"] == "bookC"
    print("Case 3 (away side -> correct book attribution) PASS:", d_v4_away)

    books_case4 = [
        {"bookmaker": "bookA", "home_moneyline": -120, "away_moneyline": float("nan")},
        {"bookmaker": "bookB", "home_moneyline": -140, "away_moneyline": 110},
    ]
    best4 = select_best_price(books_case4)
    assert best4["AWAY"]["book"] == "bookB" and best4["AWAY"]["n_books_quoting"] == 1
    assert best4["HOME"]["book"] == "bookA" and best4["HOME"]["n_books_quoting"] == 2
    print("Case 4 (missing-price book excluded, not fabricated) PASS:", best4)

    try:
        select_best_price([])
        raise AssertionError("expected ValueError on empty book_rows")
    except ValueError:
        print("Case 5 (empty book list raises, does not fabricate) PASS")

    print("\nAll self-tests passed. No frozen model, no V2.1/V3 file, touched or modified.")
