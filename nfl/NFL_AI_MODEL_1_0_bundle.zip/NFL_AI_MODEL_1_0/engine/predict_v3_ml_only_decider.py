"""
DECISION_V3_ML_ONLY -- moneyline-only decider, same frozen WINNER model,
same walk-forward-validated tau_ml threshold as V2.1, but never places a
SPREAD bet.

WHY THIS EXISTS
----------------
methodology_check:CLEAN_HOLDOUT_MODELS_2018_2021 (2026-09-21) ran the one
genuinely clean out-of-sample test available in this project: brand-new
Winner and Spread models, same architecture as the frozen production ones,
trained ONLY on 2018-2021 and graded cold on 2022-2025 -- seasons neither
model had ever seen. Result:

  - Winner model: 65.85% held-out accuracy, essentially matching its own
    claimed in-sample accuracy of 66.51%. Real generalization -- the skill
    appears genuine, not memorization.
  - Spread model: predicted-edge-vs-actual-cover correlation of 0.03 on
    held-out games -- statistical noise -- and worse average error than
    just trusting the market line. Broken out by season the spread side
    of the combined V2.1-style decider went +3.0% (2022), -11.4% on 200
    bets (2023), -8.6% (2024), +0.7% (2025): one bad, high-volume season
    dragging the total negative is what noise looks like, not what a real
    edge having a rough patch looks like.
  - Combined gated decider (both signals, V2.1's own design): 50.5% win
    rate, ROI 95% CI [-8.4%, +7.5%] -- a coin flip.
  - ML-only sub-result: 56.0% win rate, +8.04% ROI, but its own CI
    [-4.05%, +20.14%] still crosses zero -- a plausible edge, not a proven
    one, with a per-season path of +14.7% / -16.5% / +6.7% / +16.7%.

None of that licenses re-tuning thresholds against 2018-2025 again -- that
data is contaminated for both frozen base models (each was itself trained
through 2025, so no historical season is genuinely out-of-sample for them).
What it does license is a structural change: stop betting the one signal
that has never shown real skill in the only clean test that exists, and
keep only the piece backed by a model that demonstrably generalizes. This
is NOT a claim that the ML-only edge is proven -- the CI above still
crosses zero. It is exactly as unproven as V2.1's ML side always was; the
only change is removing a confirmed-noise component rather than adding a
confirmed-signal one.

tau_ml is kept at 0.19, the same value used in V2.1 and V2, because that
number was never affected by the nflverse sign-convention bug (ML EV never
depended on market_home_margin's sign) and is the same threshold examined
in the clean-holdout test above.

Reuses the exact same frozen WINNER_EPA_CORE_LR_PRE2026.joblib artifact as
engine/predict.py and engine/predict_v2_1_decider.py, unmodified. Does NOT
load or call the frozen Spread model (SPREAD_MKT_EPA_HGB_DEPLOYMENT_REFIT_
PRE2026.joblib) at all -- there is nothing for this decider to compute with
it. Does not modify engine/predict.py, predict_v2_1_decider.py, or any
frozen artifact. Not yet wired into the live app. Not authorized for real
stakes. Its only job is to be tracked prospectively, on real games, side by
side with OLD and V2.1, without ever touching 2026 outcomes to pick or
adjust tau_ml.
"""
from pathlib import Path
import joblib
import pandas as pd

TAU_ML = 0.19

BASE = Path(__file__).resolve().parent.parent  # expected to sit alongside engine/ when installed there
_ART_CANDIDATES = [
    BASE / "artifacts",
    Path("/Users/rey/Desktop/Sport Bet/NFL_AI_MODEL_1_0/artifacts"),
]


def _load_winner():
    for art in _ART_CANDIDATES:
        w = art / "WINNER_EPA_CORE_LR_PRE2026.joblib"
        if w.exists():
            return joblib.load(w)
    raise FileNotFoundError("Could not locate frozen WINNER artifact in any candidate path.")


WINNER = _load_winner()


def american_profit(o):
    o = float(o)
    if o == 0:
        raise ValueError("American odds cannot be zero")
    return o / 100 if o > 0 else 100 / abs(o)


def winner_predict(row):
    f = WINNER["features"]
    X = pd.DataFrame([{c: row.get(c) for c in f}], columns=f)
    p = float(WINNER["model"].predict_proba(X)[0, 1])
    return {"p_home_win": p, "p_away_win": 1 - p, "winner_side": "HOME" if p >= .5 else "AWAY",
            "winner_confidence": max(p, 1 - p), "ml_pick_home": int(p >= .5)}


def decide_v3_ml_only(w, home_moneyline, away_moneyline, tau_ml=TAU_ML):
    """Moneyline-only action selection. Returns dict with action/side/odds, or PASS. Never selects SPREAD."""
    p = w["p_home_win"]
    ml_side = "HOME" if p >= 0.5 else "AWAY"
    ml_odds = float(home_moneyline if ml_side == "HOME" else away_moneyline)
    p_side = p if ml_side == "HOME" else 1 - p
    ml_ev = p_side * american_profit(ml_odds) - (1 - p_side)

    if ml_ev >= tau_ml:
        action, side, odds = "ML", ml_side, ml_odds
    else:
        action, side, odds = "PASS", None, None

    return {"action": action, "side": side, "selected_odds": odds,
            "ml_ev": ml_ev, "tau_ml": tau_ml, "decider_version": "V3_ML_ONLY_TAU019"}


def predict_game_v3(*, winner_features, home_moneyline, away_moneyline, stake=50.0):
    """Same call-signature spirit as engine/predict.py::predict_game, using the moneyline-only decider."""
    w = winner_predict(winner_features)
    d = decide_v3_ml_only(w, home_moneyline, away_moneyline)
    stake = float(stake)
    profit = 0.0 if d["action"] == "PASS" else stake * american_profit(d["selected_odds"])
    return {"model_version": "NFL_AI_MODEL_1.0+DECISION_V3_ML_ONLY", "winner": w,
            "decision": d, "stake": stake, "profit_if_wins": profit,
            "total_return_if_wins": stake + profit if d["action"] != "PASS" else 0.0}
